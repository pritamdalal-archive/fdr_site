########
# Data #
########
# 1. We will need this data later.
symbols <- c("SPY", "QQQ", "IWM", "DIA") 
prices <- c(287.50, 182.48, 171.59, 257.85) 
vols <- c(0.12, 0.15, 0.14, 0.13)

############
# Matrices #
############
# 1. Matrices are common in scientific computing and can be 
#    constructed and manipulated easily in R.

# 2. Let's construct a matrix of standard normal numbers, using the
#    matrix() function and the rnorm()

##> standard_normal_matrix <- matrix(rnorm(25), 5, 5)
# first argument: a vector of numbers
# second argument: number of rows
# third argument: number of columns


# 3. It's sometimes useful to be able to look at the data, which
#    is part of what explains the prevalence of Excel in business
#    analytics.  We can use the View() function for this purpose.
##> View(standard_normal_matrix)


# 4. This is a little bit ugly to look at in the viewer, so let's 
# round all the numbers.  I can apply the round() function to the
# entire matrix like this.
##> standard_normal_matrix <- round(standard_normal_matrix, 3)

# 5. We can access the value of a matrix by using square brackets []
##> standard_normal_matrix[1, 1]
##> standard_normal_matrix[1, 2]
##> standard_normal_matrix[1,  ]
##> standard_normal_matrix[ , 1]

# 6. We can change the value or vector of a matrix using brackets.
##> standard_normal_matrix[1, 1] = 0
##> standard_normal_matrix[ , 1] = 0
##> View(standard_normal_matrix)

#############
# For Loops #
#############
# 1. R has a variety of typical control-flow statements such as 
#    if/then, while loops, etc.  We'll discuss these as needed.

# 2. In this tutorial we are going to look at just one: for loops.

# 3. A for loop allows you to iterate a fixed number of times.

# 4. The following for-loop simply prints its iterator.
##> for (ix in 1:10){
##>  print(ix)
##> }

# 5. This for-loop prints a new normal random number every time it
#    iterates through.
##> for (ix in 1:10){
##>  print(rnorm(1, 0, 1))
##> }

# 6. It is sometimes useful to nest one for-loop inside another one/
#    The following code, prints out the content of our matrix of
#    random numbers.
##> for (ix_row in 1:5){
##>   for (ix_column in 1:5){
##>     print(standard_normal_matrix[ix_row, ix_column])
##>   }
##> }

###########################
# Putting it All Together #
###########################
# 1. We are going to put all these together to do something that
#    is relevant to quantitative fiannce.

# 2. In particular, were are going to create 1000 1-year simulations
#    of SPY, at daily time intervals, using a market implied 
#    volitilty, and assuming that it follows a geometric brownian
#     motion with zero drift.

# 3. Don't worry if you have no idea what any of this means.
#    By the end of the program you definitely will.

# 4. grabbing the SPY price from our market data above
##> s_0 <- prices[1]

# 5. grabbing the SPY vol from our market data above
##> sigma <- vols[1]

# 6. In a zero drift GBM , log-returns are normally distruted 
#    with mean zero and an annual standard deviation of sigma.
#    Also, volatility scales with the squre root of time.
##> standard_normal_matrix <- matrix(rnorm(1000 * 252), 1000, 252)
##> standard_normal_matrix[ , 1] = 0

##> daily_return_factors <- exp(standard_normal_matrix * sigma/sqrt(252))

##> simulations <- matrix(rep(0, 1000*252), 1000, 252)
##> for (ix_sim in 1:1000){
##>   curr_sim <- s_0 * cumprod(daily_return_factors[ix_sim,])
##>   simulations[ix_sim, ] <- curr_sim
##> }

##> simulations <- round(simulations, 2)

##> View(simulations)
